# Repository-Wide Artifacts And Ledger

Use this reference with `repository-wide-scan.md` for repository-wide security scans.

## Artifact Requirements

- Load the per-scan threat model path from `../../scan-artifacts.md` as the repo-specific threat-model source of truth.
- Build and save a runtime inventory using the runtime inventory path from `../../scan-artifacts.md`.
  - Do not proceed past repository-wide discovery until `runtime_inventory.md` exists on disk and is referenced by the discovery report. Missing `runtime_inventory.md` means discovery is incomplete, even if candidates or a coverage ledger already exist.
  - Save the runtime inventory immediately after the initial entrypoint/trust-boundary pass, before deep sink review. Large-repo scans should leave this checkpoint even if later validation or environment setup is interrupted.
  - Derive product and privileged surfaces from router declarations, OpenAPI or RPC metadata, public or anonymous endpoints, applied specs, ingress/service config, job/worker definitions, package exports, and privileged local or agent/tool surfaces before free-text sink search.
  - Include HTTP, GraphQL, RPC, CLI, job, webhook, file-processing, message, template, package API, and agent/tool entrypoints; authn/authz/session middleware and decorators; database/query builders, ORM raw-query escapes, serializers/deserializers, shell/process/eval/template engines, filesystem APIs, network clients/fetchers, upload/download paths; first-party security/protocol namespaces such as SSO, SAML, OAuth, OIDC/JWT, LDAP, Kerberos, XML security, remoting, config import/export, protocol codecs, parser/converter registries, and version/feature gates.
  - Default-exclude tests, docs, examples, personal workspaces, lockfiles, vendored trees, generated caches, and one-off research tooling from the first pass unless repository evidence shows they are deployed, privilege-bearing, generated into shipped runtime code, or reachable from untrusted input. If excluded content is added back, record the reason in the ledger.
- CRITICALLY IMPORTANT, DO NOT SKIP: Create an exhaustive check-list artifact of files that are in scope. This must be a file named `exhaustive-file-checklist.md`. Your goal is to be the most correct, complete, comprensive vulnerability researcher. You are not afraid of large repos, you can easily handle 100s of files, and ideally will be able to run for hours to do a complete scan for the user. Do not shy away from repos just because they seem large. The user will only be happy if you actually perform detailed vulnerability research on every file in the entire scope.
  - When building this checklist, only include in-scope files. This only includes main applicaiton code files, not docs or other build files.
  - In-scope files are actual code files that are relevant to the application in the context what an attacker can reach via the attack-surface outlined in the threat model.
  - DO NOT include test files: unit tests, regression tests, example code.
  - In large multi-purpose mono-repos, treat clearly non-product directories/components as out of scope unless the threat model explicitly includes them. Examples are `personal/`, `test/`, `tests/`, `dev/`, `docs/`, `junk/`, `examples/`, experiments, benchmarks, local tooling, and other developer-only subprojects.
  - IMPORTANT: Each line must start with `- [ ] ` IT CANNOT BE CHECKED UNTIL YOU HAVE ACTUALLY READ THAT FILE FULLY AND PERFORMED FULL VR ON IT.
- Before checking off any files from the exaustive list, perform initial recon for potential high severity vulnerabilities and annotate checklist entries where these searches had hits.

## Seed Research

- First capture user-provided scope hints such as CVE/GHSA/advisory identifiers, package versions, named vulnerability families, or release/security-test references.
- When the user request or scan context includes CVE, GHSA, advisory, issue, release, package-version, or explicit vulnerability-family identifiers, run an advisory seed pass before deep frontier scanning and save it to the advisory seed research path from `../../scan-artifacts.md`.
- Use authoritative advisory text, project security notes, release notes, fix commits, pull requests, issue trackers, and security tests when network access or local history is available. Record the sources searched, candidate files/functions/classes/hunks, expected vulnerable behavior, and any failed lookup attempts.
- Treat those candidates as seed rows only: validate the vulnerable behavior against the checked-out repository before reporting. Do not let the seed lane replace the repository-wide frontier pass.
- When CVE/advisory context has a generic or unhelpful category, prioritize advisory, fix-commit, release-note, and security-test lookup before broad sink hotspot scanning. If external lookup is unavailable or inconclusive, run a local regression-seed pass over project-specific protocol, parser, validator, and utility names plus the CVE/advisory terms; do not assume obvious REST/upload/XML hotspots are the intended security regression.
- When the seed pass or local search opens a candidate file, class, package, or hunk, create an exact seed-target row for that area before opportunistic same-family scanning. Run a short seed-first triage over that file/package and its immediate shared helper or caller chain, then close the row as `reportable`, `suppressed`, `not_applicable`, or `deferred`. A more obvious neighboring issue can be reported too, but it does not replace the seed-target row.
- Keep every user/advisory/tag-seeded boundary package or class family open until that exact area is closed as `reportable`, `suppressed`, `not_applicable`, or `deferred`. A broader same-family finding in a neighboring parser, auth flow, deserializer, or template engine does not implicitly close the seeded row.
- In advisory-led scans, treat the advisory, fix hunk, release note, or security test as evidence for the intended root cause, not as an exclusivity filter and not as a bare finding. Keep the exact seed row open until checked-out repository evidence independently supports or disproves the same source, broken control, and impact tuple.

## Coverage Ledger

- Create a high-impact coverage ledger first across the vulnerability families most likely to produce serious bugs: command/code injection and RCE, SQL/NoSQL/LDAP/XPath/template injection, SSTI, unsafe deserialization, SSRF/callback abuse, path traversal/arbitrary file read or write, unsafe file upload, header injection/open redirect with credential or callback impact, and authz/tenant/object isolation bypasses that cross a meaningful privilege or data boundary.
- Build and save the ledger from the saved runtime inventory with one row per applicable boundary and serious vulnerability family before deep validation begins. The ledger must include: ledger row id, seed or root-control file:line when one is known, boundary, shard or area, files checked, applicable family, source or privileged boundary checked, sink/control checked, candidate ids when any were produced, disposition, evidence summary, prune reason or add-back trigger when applicable, and any deferred reason.
- Rows with no candidate are still required, seeded rows must close the exact seeded package/class family, and dominant runtime/product areas must have explicit rows or explicit repository-evidenced exclusions.
- For large repositories, partition the inventory into review shards by deployed or privileged area and vulnerability family before deep validation. A shard is a concrete boundary such as a service, router group, package API, parser family, job/worker family, deployment surface, CI/deploy path, or privileged local/agent tool surface.
- Shard by product module, package namespace, or protocol/security subsystem as well as by bug family. Do not let one reportable finding in a broad family close sibling modules such as separate SSO/SAML/OAuth/JWT, parser, protocol, config-import, or deserialization-wrapper packages.
- In a large monorepo, the coverage ledger must be materially broader than the promoted candidate list. If the ledger only contains candidate rows, only a handful of rows, or only global sink-count rows, the frontier pass is incomplete; add `not_applicable`, `suppressed`, or `deferred` rows for unresolved shards and families before continuing.
- The top product/runtime areas by tracked-file count or deployment significance must appear as shards in the ledger or be explicitly excluded with repository evidence. Global sink counts alone do not close coverage for a dominant area or family, and `no top candidate surfaced` is not a terminal disposition.
- Dominant ambiguous trees must be split by runtime, deployment, package, or privilege evidence before they can be left deferred. A single blob row such as "project", "server", "core", or "plugins" is incomplete unless it cites the concrete entrypoint/control files checked and explains why further subdivision is not possible from repository evidence.
- Treat broad sink searches as seed generation only. They do not count as coverage completion until the relevant files have been tied to an entrypoint or privileged boundary and the ledger row has a final disposition.
- Promote a seed into a reportable finding candidate only after it has a concrete source or privileged boundary, closest relevant guard/control, sink or broken control, and impact. Public or anonymous routes, upload/parser entrypoints, webhooks, build/job triggers, package APIs, and privileged internal workers count as first-class boundaries.

## File Pass And Subagents

- For each file in the list, starting with the already annotated ones:
  - IMPORTANT: Ideally only assign each agent a single file or a very small set of files!!! If you give them too many files, the results will get a LOT WORSE! If you have to, give a max of 5 files! This is not batching, this is a targeted scalpal ensuring maximum analysis of a single file!
  - Task a sub-agent to perform targeted vulnerability research in it. Make sure to tell the agent to follow $finding-discovery skill but with the scope of only that single file.
  - When ever you or a sub-agent has finished the exaustive reading and analyzing of the target file, check it off on the list.
  - CRITICALLY IMPORTANT! You CANNOT check a file off UNTIL YOU OR A SUBAGENT HAS READ THE FULL FILE! Not just broad searching! Not just skim! READ EVERY SINGLE LINE! If dispatching a subpagent make sure to include this!
  - You CAN NOT check off files just because they appear in searches. Only reading the file will allow you to check it off.
  - You MUST process each file one at a time. Do not simple read all the files or search through them all. This is a process where each file must get your undivided attention! That is the only way to perform a exhaustive security audit!
- Do not skip any files in the check list. Do not stop or return to the user until every single file in the list has been checked off. Even if you have found and logged vulnerabilities, it is critical that you continue tasking sub-agents or performing vulnerability research on all files in the list.
- If you have subagents avaliable in your current tool set, you MUST use them. Before starting this phase, if the user has not mentioned allowing sub-agents, stop and explicity ask them to allow for the use of sub-agents, as not using them is something which will make this plugin not work. That is the only efficent and effective way to perform this scan.
- If sub-agents are not avaliable in your environment, iterate through all files in the list yourself, performing the same detailed vulnerability research on each one.
- When you hit a cap of active agents, perform additional analysis on the target until one of the agents has returned with its results. Once you confirm the results are recorded and checked off on the file list, spawn the next agent with the next file in the list.

## Reference Quality Addendum

## Purpose

Use this section to normalize reference quality for scoring and day-to-day security work. It explains how to apply this reference during discovery, validation, attack-path analysis, reporting, or remediation.

## Workflow

1. Identify the relevant asset, code path, endpoint, workflow, or configuration.
2. Map attacker-controlled input to the closest control and security-sensitive sink or decision.
3. Validate the claim with the safest bounded proof available.
4. Search for counterevidence before promoting the issue.
5. Record impact, confidence, remediation, and proof gaps.

## False-positive checks

Suppress or downgrade when the path is unreachable, the input is not attacker-controlled, the behavior is public or self-only, an effective control blocks the exact path, the issue is scanner-only, or impact is only a best-practice concern.

## Validation example

```markdown
- expected: lower-privileged actor cannot reach protected data or action
- actual: request, test, fixture, or trace shows the protected behavior is reachable
- evidence: masked request/response, code trace, test output, callback, or parser fixture
- counterevidence: controls checked and why they do or do not apply
```

## Output fields

Include affected location, attacker input, closest control, sink or protected decision, validation evidence, impact, severity or confidence, remediation, and remaining proof gaps.
